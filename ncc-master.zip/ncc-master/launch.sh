./tg/tg -s ./bot/bot.lua
